package com.mycompany.bobbleshort;

public class BubbleSortExample {

    public static void main(String[] args) {
        String[] paises = {"México", "Brasil", "Cuba", "Chile", "Argentina", "Espanha"};

        System.out.println("Array antes da ordenação:");
        imprimirArray(paises);

        bubbleSort(paises);

        System.out.println("\nArray após a ordenação:");
        imprimirArray(paises);
    }
    public static void bubbleSort(String[] array) {
        int n = array.length;
        boolean trocou;

        for (int i = 0; i < n - 1; i++) {
            trocou = false;
            for (int j = 0; j < n - 1 - i; j++) {
              
                if (array[j].compareTo(array[j + 1]) > 0) {
                    // Troca os elementos
                    String temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    trocou = true;
                }
            }

            if (!trocou) {
                break;
            }
        }
    }

    public static void imprimirArray(String[] array) {
        for (String elemento : array) {
            System.out.print(elemento + " ");
        }
    }
}
