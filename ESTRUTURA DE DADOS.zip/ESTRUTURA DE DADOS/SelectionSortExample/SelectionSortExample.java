public class SelectionSortExample {
     public static void main(String[] args) {
        int[] numeros = {4, 2, 10, 123, -3, 32, 0, 34, 12, 91, 45, 3, 21, 87, 61};

        System.out.println("Array antes da ordenação:");
        imprimirArray(numeros);

        selectionSort(numeros);

        System.out.println("\nArray após a ordenação:");
        imprimirArray(numeros);
    }

    public static void selectionSort(int[] array) {
        int n = array.length;

        for (int i = 0; i < n - 1; i++) {
            int indiceMaximo = i;
        
            for (int j = i + 1; j < n; j++) {
                if (array[j] > array[indiceMaximo]) {
                    indiceMaximo = j;
                }
            }

            int temp = array[indiceMaximo];
            array[indiceMaximo] = array[i];
            array[i] = temp;
        }
    }

    public static void imprimirArray(int[] array) {
        for (int elemento : array) {
            System.out.print(elemento + " ");
        }
        System.out.println();
    }       
}