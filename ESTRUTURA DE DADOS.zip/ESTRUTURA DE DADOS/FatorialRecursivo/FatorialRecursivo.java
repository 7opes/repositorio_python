public class FatorialRecursivo {

    public static void main(String[] args) {
        int numero = 10;
        long resultado = calcularFatorial(numero);
        System.out.println("O fatorial de " + numero + " é: " + resultado);
    }

    // Função recursiva para calcular o fatorial de um número inteiro positivo
    public static long calcularFatorial(int n) {
        // Caso base: fatorial de 0 é 1
        if (n == 0) {
            return 1;
        }
        // Caso geral: fatorial de n é n * fatorial(n-1)
        return n * calcularFatorial(n - 1);
    }
}
