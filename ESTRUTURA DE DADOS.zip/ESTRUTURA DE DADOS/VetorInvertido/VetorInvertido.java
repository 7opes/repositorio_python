public class VetorInvertido {

    public static void inverter(double[] vet, int n) {
        if (vet == null || n <= 0 || n > vet.length) {
            System.out.println("Vetor inválido ou quantidade de elementos incorreta.");
            return;
        }
 
        for (int i = 0; i < n / 2; i++) {
           
            double temp = vet[i];
            vet[i] = vet[n - 1 - i];
            vet[n - 1 - i] = temp;
        }
    }
    public static void imprimirVetor(double[] vet, int n) {
        for (int i = 0; i < n; i++) {
            System.out.print(vet[i] + " ");
        }
        System.out.println();
    }
    public static void main(String[] args) {
        double[] vetor = {1.5, 2.7, 3.0, 4.2, 5.1};
        int tamanhoReal = 5;

        System.out.println("Vetor antes da inversão:");
        imprimirVetor(vetor, tamanhoReal);

        inverter(vetor, tamanhoReal);

        System.out.println("Vetor após a inversão:");
        imprimirVetor(vetor, tamanhoReal);
    }
}
